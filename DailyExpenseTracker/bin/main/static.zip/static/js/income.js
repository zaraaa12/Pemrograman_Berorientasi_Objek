const apiUrl = "http://localhost:8080/api/transactions";
const transactionList = document.getElementById("transactionList");
const totalBalance = document.getElementById("totalBalance");

document.addEventListener("DOMContentLoaded", loadTransactions);

function loadTransactions() {
  fetch(apiUrl)
    .then((res) => res.json())
    .then((data) => {
      const incomes = data.filter(t => t.type === "income");
      renderTransactions(incomes);
      updateBalance(data); 
    });
}

function renderTransactions(transactions) {
  transactionList.innerHTML = "";
  transactions.forEach(t => {
    const div = document.createElement("div");
    div.className = `transaction-card ${t.type}`;
    div.innerHTML = `
      <i class="fas fa-wallet"></i>
      <span>${t.description}</span>
      <span class="amount">+$${t.amount.toFixed(2)}</span>
      <button class="btn action edit"><i class="fas fa-edit"></i></button>
      <button class="btn action delete"><i class="fas fa-trash-alt"></i></button>
    `;
    div.querySelector(".delete").onclick = () => deleteTransaction(t.id);
    div.querySelector(".edit").onclick = () => openEditModal(t);
    transactionList.appendChild(div);
  });
}

function updateBalance(transactions) {
  let income = 0,
    expense = 0;
  transactions.forEach((t) => {
    if (t.type === "income") income += t.amount;
    else expense += t.amount;
  });

  const total = income - expense;
  totalBalance.textContent = `$${total.toFixed(2)}`;
  document.querySelector(".summary .income").innerHTML = `<i class="fas fa-arrow-up"></i> $${income.toFixed(2)}`;
  document.querySelector(".summary .expense").innerHTML = `<i class="fas fa-arrow-down"></i> $${expense.toFixed(2)}`;
}

function deleteTransaction(id) {
  console.log("Deleting ID:", id);
  if (!confirm("Yakin ingin menghapus ini?")) return;
  fetch(`${apiUrl}/${id}`, { method: "DELETE" })
    .then(res => {
      console.log("DELETE response status:", res.status);
      if (!res.ok) throw new Error("Delete gagal: " + res.status);
      loadTransactions();
    })
    .catch(err => console.error("Error deleting:", err));
}

function openEditModal(tx) {
  const modal = document.getElementById("modal");
  document.getElementById("idInput").value = tx.id;
  document.getElementById("descInput").value = tx.description;
  document.getElementById("amountInput").value = tx.amount;
  document.getElementById("transactionType").value = tx.type;
  modal.classList.remove("hidden");
}

function initIncomeModal() {
  const modal = document.getElementById("modal");
  const addBtn = document.querySelector(".add-btn");
  const submitBtn = document.getElementById("submitBtn");
  const desc = document.getElementById("descInput");
  const amount = document.getElementById("amountInput");
  const type = document.getElementById("transactionType");
  const idHidden = document.getElementById("idInput");

  transactionType.value = "income"; // paksa tipe income

  addBtn.addEventListener("click", () => modal.classList.remove("hidden"));
  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.classList.add("hidden");
  });

  modal.onclick = e => {
    if (e.target === modal) modal.classList.add("hidden");
  };

  submitBtn.addEventListener("click", () => {
    const desc = descInput.value.trim();
    const amount = parseFloat(amountInput.value);

    if (!desc || isNaN(amount)) return alert("Isi dengan benar");

    const transaction = {
      description: desc,
      amount: amount,
      type: transactionType.value,
    };

    fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(transaction),
    }).then(() => {
      modal.classList.add("hidden");
      descInput.value = "";
      amountInput.value = "";
      loadTransactions();
    });
  });
}